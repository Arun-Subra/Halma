import copy
import tkinter as tk
import customtkinter as ctk
from CTkMessagebox import CTkMessagebox
import math
from PIL import Image, ImageTk
from module import Player
from module import DatabaseManager
from datetime import datetime
import threading

class HalmaGame:
    def __init__(self, root):
        # Create GUI window
        self.root = root
        self.root.title("Halma Game")
        self.root.configure(background="#331D2C")

        # Set up Database if not already
        self.db = DatabaseManager("halma_games.db")
        self.db.setup_tables()

        # Set options
        self.grid_size = 10
        self.cell_size = 70
        self.side = self.cell_size * self.grid_size
        self.board_colours = ["#C70039", "#FF5733"]
        self.highlight_colour = "yellow"
        self.button_height = 25
        self.button_width = 50

        # Open the piece images using PILLOW
        self.img = Image.open("red.png").resize((self.cell_size - 5, self.cell_size - 5), Image.ANTIALIAS)
        self.piece1 = ImageTk.PhotoImage(self.img)

        self.img = Image.open("blue.png").resize((self.cell_size - 5, self.cell_size - 5), Image.ANTIALIAS)
        self.piece2 = ImageTk.PhotoImage(self.img)

        self.player_one_positions = [
            (self.grid_size - 1, self.grid_size - 1),

            (self.grid_size - 1, self.grid_size - 2), (self.grid_size - 2, self.grid_size - 1),

            (self.grid_size - 1, self.grid_size - 3), (self.grid_size - 2, self.grid_size - 2), 
            (self.grid_size - 3, self.grid_size - 1),

            (self.grid_size - 1, self.grid_size - 4), (self.grid_size - 2, self.grid_size - 3), 
            (self.grid_size - 3, self.grid_size - 2), (self.grid_size - 4, self.grid_size - 1),
        ]

        self.player_two_positions = [
            (0, 0),
            (0, 1), (1, 0),
            (0, 2), (1, 1), (2, 0),
            (0, 3), (1, 2), (2, 1), (3, 0),
        ]

        self.canvas = ctk.CTkCanvas(self.root, width=self.side, height=self.side)
        self.canvas.configure(background="black")
        self.canvas.grid(row=0, column=0, padx=10, pady=10)
        
        self.set_game()
        self.canvas.unbind("<Button-1>")

        # Create Side Panel
        self.side_panel = ctk.CTkFrame(self.root)
        self.side_panel.grid(row=0, column=1, padx=20, sticky="w")

        self.set_menu()

    def set_game(self):
        # Create the game board and variables
        self.playing = True
        self.selected_piece = None
        self.jumped_from = None
        self.current_player = 1
        self.jumping = False
        self.move_history = []
        self.num_moves = 0
        self.show_move = 0
        self.in_play = True

        self.board = [[0 for x in range(self.grid_size)] for y in range(self.grid_size)]

        for row, col in self.player_one_positions:
            self.board[row][col] = 1

        for row, col in self.player_two_positions:
            self.board[row][col] = 2
            
        self.draw_board()

        self.move_history.append(copy.deepcopy(self.board))

        # Register selection
        self.canvas.bind("<Button-1>", self.on_left_click)
        self.root.bind("<Left>",  lambda event: self.prev_move())
        self.root.bind("<Right>",  lambda event: self.next_move())
        self.root.bind("<Up>",  lambda event: self.end())
        self.root.bind("<Down>",  lambda event: self.beginning())

    def set_game_panel(self):
        self.clear_side_panel()

        self.beginning_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="<<-", command=self.beginning)
        self.beginning_button.grid(row=0, column=0)

        self.prev_move_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="<-", command=self.prev_move)
        self.prev_move_button.grid(row=0, column=1)

        self.next_move_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="->", command=self.next_move)
        self.next_move_button.grid(row=0, column=2)

        self.end_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="->>", command=self.end)
        self.end_button.grid(row=0, column=3)

        self.move_string = ctk.StringVar()
        # TODO get moves
        self.move_string.set("Test")
        move_text = ctk.CTkLabel(self.side_panel, textvariable=self.move_string, anchor="nw")
        move_text.grid(row=1, column=0, columnspan=4, sticky="new")
        
        self.undo_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="⎌", command=self.undo)
        self.undo_button.configure(state="disabled")
        self.undo_button.grid(row=2, column=0)

        self.confirm_button = ctk.CTkButton(self.side_panel, text="Confirm", height=self.button_height, width=self.button_width*2, command=self.confirm)
        self.confirm_button.configure(state="disabled")
        self.confirm_button.grid(row=2, column=1, columnspan=2)

        #New game
        self.new_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="+", command=self.new_game)
        self.new_button.grid(row=2, column=3)

        self.info_string = ctk.StringVar()
        self.info_string.set(self.player_names[self.current_player - 1].get() + "'s Turn")
        info_text = ctk.CTkLabel(self.side_panel, textvariable=self.info_string, anchor="nw", bg_color="red")
        info_text.grid(row=3, column=0, columnspan=2, sticky="new")

        self.set_in_play()

    def set_menu(self):
        self.clear_side_panel()
        
        play_player_button = ctk.CTkButton(self.side_panel, height=self.button_height*4, width=self.button_width*4, text="Play vs Player", command=lambda: self.start_game(False))
        play_player_button.grid(row=0, column=0)

        play_ai_button = ctk.CTkButton(self.side_panel, height=self.button_height*4, width=self.button_width*4, text="Play vs AI", command=lambda: self.start_game(True))
        play_ai_button.grid(row=1, column=0)

        analyse_game_button = ctk.CTkButton(self.side_panel, height=self.button_height*4, width=self.button_width*4, text="Analyse Game", command=self.analyse_game)
        analyse_game_button.grid(row=2, column=0)

        manage_players_button = ctk.CTkButton(self.side_panel, height=self.button_height*4, width=self.button_width*4, text="Manage Players", command=self.manage_players)
        manage_players_button.grid(row=3, column=0)

    def clear_side_panel(self):
       for widgets in self.side_panel.winfo_children():
            widgets.destroy()

    def draw_board(self):
        # Delete Previous Board
        self.canvas.delete("pieces")

        if self.in_play:
            position = self.board
        else:
            position = self.move_history[self.show_move]
        if self.selected_piece:
            valid_moves = self.show_valid_moves(position, self.selected_piece[0], self.selected_piece[1])
        else:
            valid_moves = []

        # Adjustment to centre images correctly
        image_adjustment = 35
        
        for row in range(self.grid_size):
            for col in range(self.grid_size):
                x_start, y_start = col * self.cell_size, row * self.cell_size
                x_finish, y_finish = x_start + self.cell_size, y_start + self.cell_size
                colour = self.board_colours[0] if (row + col) % 2 == 0 else self.board_colours[1]

                if (row, col) == self.selected_piece and self.in_play:
                    self.canvas.create_rectangle(x_start, y_start, x_finish, y_finish, fill=self.highlight_colour, tags="pieces")
                elif (row, col) in valid_moves and self.in_play:
                    self.canvas.create_rectangle(x_start, y_start, x_finish, y_finish, fill="grey", tags="pieces")
                elif (row, col) in (self.player_one_positions + self.player_two_positions):
                    self.canvas.create_rectangle(x_start, y_start, x_finish, y_finish, fill="blue", tags="pieces")
                else:
                    self.canvas.create_rectangle(x_start, y_start, x_finish, y_finish, fill=colour, tags="pieces")
                
                if position[row][col] == 1:
                    self.canvas.create_image(x_start + image_adjustment, y_start + image_adjustment, anchor="center", image=self.piece1, tags="pieces")
                elif position[row][col] == 2:
                    self.canvas.create_image(x_start + image_adjustment, y_start + image_adjustment, anchor="center", image=self.piece2, tags="pieces")
    
    def start_game(self, ai):
        self.ai = ai
        if ai:
            self.player_names = [ctk.StringVar(), ctk.StringVar()]
            self.set_game()
            self.set_game_panel()
        else:
            self.choose_pvp()

    def choose_ai(self):
        self.clear_side_panel()
        players = self.db.get_players()
        player_names = [x.name for x in players]

        player_label = ctk.CTkLabel(self.side_panel, text="Player Name", anchor="nw", height=self.button_height, width=self.button_width)
        player_label.grid(row=0)
        self.player_one = ctk.StringVar()
        self.player_one.set(player_names[0])
        drop_one = ctk.CTkOptionMenu(master=self.side_panel, height=self.button_height, width=self.button_width*4, values=player_names, variable=self.player_one)
        drop_one.grid(row=1)

        player_two_label = ctk.CTkLabel(self.side_panel, text="AI Difficulty", anchor="nw", height=self.button_height, width=self.button_width)
        player_two_label.grid(row=2)
        self.player_two = ctk.StringVar()
        self.player_two.set(player_names[1])
        drop_two = ctk.CTkOptionMenu(master=self.side_panel, height=self.button_height, width=self.button_width*4, values=player_names, variable=self.player_two)
        drop_two.grid(row=3)

    def choose_pvp(self):
        self.clear_side_panel()
        players = self.db.get_players()
        player_names = [x.name for x in players]

        player_one_label = ctk.CTkLabel(self.side_panel, text="Player One Name", anchor="nw", height=self.button_height, width=self.button_width)
        player_one_label.grid(row=0)
        self.player_one = ctk.StringVar()
        self.player_one.set(player_names[0])
        drop_one = ctk.CTkOptionMenu(master=self.side_panel, height=self.button_height, width=self.button_width*4, values=player_names, variable=self.player_one)
        drop_one.grid(row=1)

        player_two_label = ctk.CTkLabel(self.side_panel, text="Player Two Name", anchor="nw", height=self.button_height, width=self.button_width)
        player_two_label.grid(row=2)
        self.player_two = ctk.StringVar()
        self.player_two.set(player_names[1])
        drop_two = ctk.CTkOptionMenu(master=self.side_panel, height=self.button_height, width=self.button_width*4, values=player_names, variable=self.player_two)
        drop_two.grid(row=3)
        
        submit_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="Submit", command=self.submit)
        submit_button.grid(row=4)

    def submit(self):
        self.player_names = [self.player_one, self.player_two]
        self.set_game()
        self.set_game_panel()

    def analyse_game(self):
        self.set_game()
        self.root.unbind("<Button-1>")
        self.set_analysis_panel()

    def set_analysis_panel(self):
        self.clear_side_panel()

        self.beginning_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="<<-", command=self.beginning)
        self.beginning_button.grid(row=0, column=0)

        self.prev_move_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="<-", command=self.prev_move)
        self.prev_move_button.grid(row=0, column=1)

        self.next_move_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="->", command=self.next_move)
        self.next_move_button.grid(row=0, column=2)

        self.end_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width, text="->>", command=self.end)
        self.end_button.grid(row=0, column=3)

        self.best_move_button = ctk.CTkButton(self.side_panel, height=self.button_height, width=self.button_width*4, text="View Best Move", command=self.view_best_move)
        self.best_move_button.grid(row=1, columnspan=4)

    def view_best_move(self):
        position = copy.deepcopy(self.board)
        self.best_move_button.grid_forget()
        best_move = threading.Thread(target=self.minimax, args=(position, 2, -math.inf, math.inf, False))
        progressbar = ctk.CTkProgressBar(self.side_panel, orientation="horizontal", mode="indeterminate")
        progressbar.grid(row=1, columnspan=4)
        progressbar.start()
        best_move.start()
        # best_move.join()
        # progressbar.stop()
        # progressbar.grid_forget()
        # best_move_string = move_text = ctk.CTkLabel(self.side_panel, text=str(results[0]), anchor="nw")
        # best_move_string.grid(row=1, columnspan=4)

    def manage_players(self):
        pass
        
    def on_left_click(self, event):
        row, col = event.y // self.cell_size, event.x // self.cell_size
        if row < self.grid_size and col < self.grid_size and self.in_play:
            if self.board[row][col] == self.current_player and not self.jumping: # jumping correction
                self.select_piece(row, col)
            elif self.selected_piece:
                self.move_piece(row, col)  

    def select_piece(self, row, col):
        if self.selected_piece == (row, col):
            self.selected_piece = None
        else:
            self.selected_piece = (row, col)
        # Update board to show selected piece
        self.draw_board()

    def show_valid_moves(self, position, row, col):
        moves = []
        for x in range(-2, 3):
            for y in range(-2, 3):
                if 0 <= (row + x) < self.grid_size and 0 <= (col + y) < self.grid_size:
                    if self.valid_move(position, row, col, row + x, col + y)[0]:
                        moves.append((row + x, col + y))
        return moves
    
    def move_piece(self, row, col):
        prev_row, prev_col = self.selected_piece
        valid, jump = self.valid_move(self.board, prev_row, prev_col, row, col)
        if valid:
            # First jump
            if not self.jumping and jump:
                self.jumped_from = self.selected_piece
            # Set if jumping or not
            self.jumping = jump
            self.board[row][col] = self.current_player
            self.board[prev_row][prev_col] = 0
            if self.jumping:
                self.confirm_button.configure(state="normal") # Add to design
                self.selected_piece = (row, col)
                self.draw_board()
            else:
                self.switch_player()
        elif not self.jumping:
            self.selected_piece = None
            self.draw_board()
    
    def valid_move(self, position, src_row, src_col, dest_row, dest_col):
        vector = (dest_row - src_row, dest_col - src_col)
        jump = False
        # Check if move
        valid = False
        if (vector[0] == 0 or abs(vector[0]) == 1) and (vector[1] == 0 or abs(vector[1]) == 1) \
            and not self.jumping:
            valid = True
        # Check if jump
        elif (vector[0] == 0 or abs(vector[0]) == 2) and (vector[1] == 0 or abs(vector[1]) == 2) \
            and position[src_row + vector[0] // 2][src_col + vector[1] // 2] != 0 \
                and (dest_row, dest_col) != self.jumped_from:
            valid = True
            jump = True
        # Check if there is a piece in destination square
        if position[dest_row][dest_col] != 0:
            valid = False
        return valid, jump
    
    def switch_player(self):
        # Deselect any pieces
        self.selected_piece = None
        self.jumped_from = None

        # Add move to moves list
        self.move_history.append(copy.deepcopy(self.board))
        self.num_moves += 1
        if self.num_moves >= 1:
            self.undo_button.configure(state="normal")
        self.show_move = self.num_moves

        # Update board to show any moves
        self.draw_board()
        self.set_in_play()
        if self.check_win(self.board):
            self.game_over()
            return None
        
        self.current_player = 3 - self.current_player
        self.info_string.set(self.player_names[self.current_player - 1].get() + "'s Turn")
        if self.ai and self.current_player == 2:
            self.ai_turn()

    def ai_turn(self):
        best_move = self.minimax(copy.deepcopy(self.board), 3, -math.inf, math.inf, self.current_player == 1)[1]
        self.apply_move(self.board, self.current_player, best_move)
        self.switch_player()

    def minimax(self, position, depth, alpha, beta, max_player):
        if depth == 0 or self.check_win(position):
            return self.evaluate(position), None
        valid_moves = self.get_valid_moves(position, max_player)
        best_move = None
        if max_player:
            max_eval = -math.inf
            for move in valid_moves:
                new_pos = self.apply_move(copy.deepcopy(position), 1, move)
                eval = self.minimax(new_pos, depth - 1, alpha, beta, False)[0]
                if eval > max_eval:
                    max_eval = eval
                    best_move = move

                # Alpha-beta pruning
                alpha = max(alpha, eval)
                if beta <= alpha:
                    break
            return (max_eval, best_move)
        else:
            min_eval = math.inf
            for move in valid_moves:
                new_pos = self.apply_move(copy.deepcopy(position), 2, move)
                eval = self.minimax(new_pos, depth - 1, alpha, beta, True)[0]
                if eval < min_eval:
                    min_eval = eval
                    best_move = move

                # Alpha-beta pruning
                beta = min(beta, eval)
                if beta <= alpha:
                    break
            return (min_eval, best_move)

    def evaluate(self, position):
        win = self.check_win(position)
        if win == 1:
            return 5000
        elif win == 2:
            return -5000
        score = 0
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                part = 0
                if position[i][j] == 1:
                    min_distance = self.grid_size ** 2 + 1
                    for target in self.player_two_positions:
                        if position[target[0]][target[1]] != 0:
                            distance = ((i-target[0])**2 + (j-target[1])**2)**0.5
                            if distance < min_distance:
                                min_distance = distance
                    part -= min_distance
                elif position[i][j] == 2:
                    min_distance = self.grid_size ** 2 + 1
                    for target in self.player_one_positions:
                        if position[target[0]][target[1]] != 0:
                            distance = ((i-target[0])**2 + (j-target[1])**2)**0.5
                            if distance < min_distance:
                                min_distance = distance
                    part += min_distance
                score += part
        return score
    
    def get_valid_moves(self, position, max_player):
        #TODO: ADD JUMPING MOVES
        moves = []
        jumps = []
        player = 1 if max_player else 2
        for row in range(self.grid_size):
            for col in range(self.grid_size):
                if position[row][col] == player:
                    for x in range(-2, 3):
                        for y in range(-2, 3):
                            if 0 <= (row + x) < self.grid_size and 0 <= (col + y) < self.grid_size:
                                valid, jumping = self.valid_move(position, row, col, row + x, col + y)
                                if valid:
                                    if jumping:
                                        jumps.append((row, col, row + x, col + y))
                                    else:
                                        moves.append((row, col, row + x, col + y))
        changed = True
        while changed:
            changed = False
            new = []
            for jump in jumps:
                new_pos = self.apply_move(copy.deepcopy(position), player, jump)
                for x in range(-2, 3, 2):
                    for y in range(-2, 3, 2):
                        if 0 <= (jump[2] + x) < self.grid_size and 0 <= (jump[3] + y) < self.grid_size and not (jump[0] == jump[2] + x and jump[1] == jump[3] + y):
                            if (jump[0], jump[1], jump[2] + x, jump[3] + y) not in jumps and self.valid_move(new_pos, jump[2], jump[3], jump[2] + x, jump[3] + y)[0]:
                                    new.append((jump[0], jump[1], jump[2] + x, jump[3] + y))
                                    changed = True
            # Put moves likely to be better first
            jumps = new + jumps
        return jumps + moves
    
    def apply_move(self, position, player, move):
        position[move[2]][move[3]] = player
        position[move[0]][move[1]] = 0
        return position
    
    def check_win(self, position):
        win = True
        enemy = False
        for coords in self.player_one_positions:
            if position[coords[0]][coords[1]] == 0:
                win = False
            elif position[coords[0]][coords[1]] == 2:
                enemy = True
        if win and enemy:
            return 2
        win = True
        enemy = False
        for coords in self.player_two_positions:
            if position[coords[0]][coords[1]] == 0:
                win = False
            elif position[coords[0]][coords[1]] == 1:
                enemy = True
        if win and enemy:
            return 1
        return 0
    
    def game_over(self):
        self.playing = False
        self.root.unbind("<Button-1>")
        self.root.unbind("<Left>")
        self.root.unbind("<Right>")
        self.root.unbind("<Up>")
        self.root.unbind("<Down>")
        winner = self.player_names[self.current_player - 1]
        self.info_string.set(winner.get() + " Wins!")
        self.undo_button.configure(state="disabled")
        if self.num_moves > 0:
            msg = CTkMessagebox(title="Question", 
                            message="Do you want to save this game?", 
                            icon="question", 
                            option_1="No", 
                            option_2="Yes", 
            )     
            response = msg.get()
            if response == "Yes":
                self.save_game()
    
    def new_game(self):
        if self.playing:
            self.current_player = 3 - self.current_player
            self.game_over()
        self.start_game(self.ai)

    def save_game(self):
        player_one_id = self.db.get_player_id(self.player_names[0].get())
        player_two_id = self.db.get_player_id(self.player_names[1].get())
        date_played = datetime.today().strftime('%Y-%m-%d')
        time_played = datetime.now().strftime('%H:%M:%S')
        game_id = self.db.add_game(player_one_id, player_one_id, self.current_player, self.grid_size, date_played, time_played, self.num_moves)
        for move in range(self.num_moves):
            pos = [[str(x) for x in row] for row in copy.deepcopy(self.move_history[move])]
            pos_string = ",".join(["".join(x) for x in pos])
            self.db.add_move(game_id, move + 1, "BLAH", "BLAH", pos_string)

    def set_in_play(self):
        if self.show_move == 0:
            self.beginning_button.configure(state="disabled")
            self.prev_move_button.configure(state="disabled")
        else:
            self.beginning_button.configure(state="normal")
            self.prev_move_button.configure(state="normal")

        if self.show_move == self.num_moves:
            self.end_button.configure(state="disabled")
            self.next_move_button.configure(state="disabled")
            self.in_play = True
        else:
            self.end_button.configure(state="normal")
            self.next_move_button.configure(state="normal")
            self.in_play = False
        self.draw_board()

    def beginning(self):
        self.show_move = 0
        self.set_in_play()
        
    def prev_move(self):
        if self.show_move != 0:
            self.show_move -= 1
        self.set_in_play()

    def next_move(self):
        if self.show_move < self.num_moves:
            self.show_move += 1
        self.set_in_play()

    def end(self):
        self.show_move = self.num_moves
        self.set_in_play()

    def undo(self):
        self.move_history.pop()
        self.board = copy.deepcopy(self.move_history[-1])
        self.num_moves -= 1
        if self.ai:
            self.move_history.pop()
            self.board = copy.deepcopy(self.move_history[-1])
            self.num_moves -= 1
        self.undo_button.configure(state="disabled")
        self.show_move = self.num_moves
        self.selected_piece = None
        if not self.ai:
            self.current_player = 3 - self.current_player
            self.info_string.set(self.player_names[self.current_player - 1].get() + "'s Turn")
        self.set_in_play()
        self.draw_board()

    def confirm(self):
        self.jumping = False
        self.confirm_button.configure(state="disabled")
        self.switch_player()

if __name__ == "__main__":
    root = ctk.CTk()
    halma_game = HalmaGame(root)
    root.mainloop()