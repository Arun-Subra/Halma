import sqlite3
class Player:
    def __init__(self, id, name):
        self.id = id
        self.name = name
 
class DatabaseManager:
    def __init__(self, db_name):
        self.db_name = db_name
        self.con = None

    def create_con(self):
        if not self.con:
            try:
                self.con = sqlite3.connect(self.db_name)
            except Exception as e:
                print(e)
                return False
        return True
    
    def close_con(self):
        if self.con:
            self.con.close()
    
    def create_table(self, sql):
        self.create_con()
        try:
            cursor = self.con.cursor()
            cursor.execute(sql)
        except Exception as e:
            print(e)
        self.con.commit()

    def player_exists(self, player_name):
        players = self.get_players()
        for player in players:
            if player.name == player_name:
                return True
        return False
    
    def get_player_id(self, player_name):
        self.create_con()
        query = f"""SELECT player_id FROM player WHERE name = '{player_name}';"""
        cursor = self.con.cursor()
        id = cursor.execute(query).fetchall()[0][0]
        print(id)
        return id
    
    def add_player(self, player):
        if not self.player_exists(player):
            sql_add_guest_players = """INSERT INTO player(name) VALUES (?);"""
            cursor = self.con.cursor()
            cursor.execute(sql_add_guest_players, (player,))
            self.con.commit()
            return True
        else:
            return False
        
    def add_game(self, player_one_id, player_two_id, result, board_size, date_played, time_played, num_moves):
        self.create_con()
        values = [player_one_id, player_two_id, result, board_size, date_played, time_played, num_moves]
        print(values)
        query = """INSERT INTO game(player_one_id, player_two_id, result, board_size, date_played, time_played, num_moves) VALUES (?,?,?,?,?,?,?)"""
        cursor = self.con.cursor()
        cursor.execute(query, values)
        self.con.commit()
        return cursor.lastrowid
    
    def add_move(self, game_id, move_id, original_square, destination_squre, position):
        self.create_con()
        values = [game_id, move_id, original_square, destination_squre, position]
        query = """INSERT INTO move(game_id, move_id, original_square, destination_square, position) VALUES (?,?,?,?,?)"""
        cursor = self.con.cursor()
        cursor.execute(query, values)
        self.con.commit()

    def setup_tables(self):
        sql_create_game_table = """ CREATE TABLE IF NOT EXISTS game (
                                            game_id integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                                            player_one_id integer NOT NULL,
                                            player_two_id integer NOT NULL,
                                            result integer NOT NULL,
                                            board_size integer NOT NULL,
                                            date_played text NOT NULL,
                                            time_played text NOT NULL,
                                            num_moves integer NOT NULL
                                        ); """
        
        sql_create_player_table = """ CREATE TABLE IF NOT EXISTS player (
                                            player_id integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                                            name text NOT NULL
                                        ); """
        
        sql_create_move_table = """ CREATE TABLE IF NOT EXISTS move (
                                            game_id integer NOT NULL,
                                            move_id integer NOT NULL,
                                            original_square text NOT NULL,
                                            destination_square text NOT NULL,
                                            position text NOT NULL,
                                            PRIMARY KEY (game_id, move_id)
                                        ); """
        
        self.create_table(sql_create_game_table)
        self.create_table(sql_create_player_table)
        self.create_table(sql_create_move_table)
        self.add_player("Guest1")
        self.add_player("Guest2")

    def get_players(self):
        self.create_con()
        sql_get_players = """SELECT player_id, name FROM player;"""
        cursor = self.con.cursor()
        # TODO get rid of Player class
        players = []
        for x in cursor.execute(sql_get_players).fetchall():
            players.append(Player(x[0], x[1]))
        return players


